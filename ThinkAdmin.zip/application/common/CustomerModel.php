<?php
namespace app\common\model;

use think\Model;
use think\Db;

class CustomerModel extends model
{
    public $table = 'v9_gn_customer';

    /**
     * 获取全部客户
     */
    public static function getCustomer()
    {

    }

}