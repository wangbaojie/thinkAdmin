<?php
//000000000030
 exit();?>
think_serialize:a:7:{s:2:"id";i:147;s:4:"node";s:20:"customer/index/index";s:5:"title";s:12:"客户列表";s:7:"is_menu";i:1;s:7:"is_auth";i:1;s:8:"is_login";i:1;s:9:"create_at";s:19:"2018-05-16 16:17:57";}