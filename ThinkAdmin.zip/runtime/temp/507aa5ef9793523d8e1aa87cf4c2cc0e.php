<?php /*a:1:{s:67:"D:\phpStudy\WWW\ThinkAdmin\application\store\view\express\form.html";i:1525718710;}*/ ?>
<form class="layui-form layui-box" style='padding:25px 30px 20px 0' action="<?php echo request()->url(); ?>" data-auto="true" method="post">

    <div class="layui-form-item">
        <label class="layui-form-label">快递公司名称</label>
        <div class="layui-input-block">
            <input autofocus name="express_title" value='<?php echo htmlentities((isset($vo['express_title']) && ($vo['express_title'] !== '')?$vo['express_title']:"")); ?>' required="required"
                   title="请输入快递公司名称" placeholder="请输入快递公司名称" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">快递公司代码</label>
        <div class="layui-input-block">
            <input autofocus name="express_code" value='<?php echo htmlentities((isset($vo['express_code']) && ($vo['express_code'] !== '')?$vo['express_code']:"")); ?>' required="required"
                   title="请输入快递公司代码" placeholder="请输入快递公司代码" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">快递公司描述</label>
        <div class="layui-input-block">
            <textarea placeholder="请输入快递公司描述" title="请输入快递公司描述"
                      class="layui-textarea" name="express_desc"><?php echo htmlentities((isset($vo['express_desc']) && ($vo['express_desc'] !== '')?$vo['express_desc']:"")); ?></textarea>
        </div>
    </div>

    <div class="hr-line-dashed"></div>

    <div class="layui-form-item text-center">
        <?php if(isset($vo['id'])): ?><input type='hidden' value='<?php echo htmlentities($vo['id']); ?>' name='id'/><?php endif; ?>
        <button class="layui-btn" type='submit'>保存数据</button>
        <button class="layui-btn layui-btn-danger" type='button' data-confirm="确定要取消编辑吗？" data-close>取消编辑</button>
    </div>

    <script>window.form.render();</script>
</form>
