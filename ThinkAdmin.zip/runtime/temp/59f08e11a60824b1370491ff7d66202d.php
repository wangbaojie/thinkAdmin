<?php /*a:1:{s:67:"D:\phpStudy\WWW\ThinkAdmin\application\admin\view\token\change.html";i:1543979942;}*/ ?>
<form onsubmit="return false;" data-auto="true" method="post">
    <input type="hidden" value="resort" name="action"/>
    <?php if(empty($domain_ip)): ?>
    <p class="help-block text-center well">没 有 记 录 哦！</p>
    <?php else: ?>
    <table class="layui-table" lay-skin="line" lay-size="sm">
        <thead>
        <tr>
            <th class='text-left'>ID</th>
            <th class='text-left'>域名</th>
            <th class='text-left'>ip</th>
            <th class='text-left'>网站title</th>
            <th class='text-left'>变更日期</th>
            <th class='text-left'>操作</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach($domain_ip as $key=>$vo): ?>
        <tr>
            <td class='text-left'><?php echo htmlentities($vo['id']); ?></td>
            <td class='text-left'><?php echo htmlentities($vo['domain']); ?></td>
            <td class='text-left'><?php echo htmlentities($vo['ip']); ?></td>
            <td class='text-left'><?php echo htmlentities($vo['title']); ?></td>
            <td class='text-left'><?php echo htmlentities(date('Y年m月d日 H:i:s',!is_numeric($vo['created_at'])? strtotime($vo['created_at']) : $vo['created_at'])); ?></td>
            <td></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php if(isset($page)): ?><p><?php echo $page; ?></p><?php endif; endif; ?>
</form>