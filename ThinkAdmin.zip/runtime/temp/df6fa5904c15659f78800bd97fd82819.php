<?php /*a:4:{s:72:"D:\phpStudy\WWW\ThinkAdmin\application\wechat\view\fans_block\index.html";i:1525718710;s:69:"D:\phpStudy\WWW\ThinkAdmin\application\admin\view\public\content.html";i:1525718710;s:71:"D:\phpStudy\WWW\ThinkAdmin\application\wechat\view\fans\search_inc.html";i:1525718710;s:69:"D:\phpStudy\WWW\ThinkAdmin\application\wechat\view\fans\tags_inc.html";i:1525718710;}*/ ?>
<!-- 右则内容区域 开始 -->

<div class="layui-card">
    <!--<?php if(!(empty($title) || (($title instanceof \think\Collection || $title instanceof \think\Paginator ) && $title->isEmpty()))): ?>-->
    <div class="layui-header notselect">
        <div class="pull-left"><span><?php echo htmlentities($title); ?></span></div>
        <div class="pull-right margin-right-15 nowrap">
<!--<?php if(auth('wechat/block/backdel')): ?>-->
<button data-update="" data-action="<?php echo url('backdel'); ?>" class='layui-btn layui-btn-sm layui-btn-primary'>批量移出粉丝</button>
<!--<?php endif; ?>-->
<!--<?php if(auth('wechat/fans/sync')): ?>-->
<button data-load="<?php echo url('wechat/fans/sync'); ?>" class='layui-btn layui-btn-sm layui-btn-primary'>远程获取粉丝</button>
<!--<?php endif; ?>-->
</div>
    </div>
    <!--<?php endif; ?>-->
    <div class="layui-card-body">
<!-- 表单搜索 开始 -->
<form class="layui-form layui-form-pane form-search" action="<?php echo request()->url(); ?>" onsubmit="return false" method="get">

    <div class="layui-form-item layui-inline">
        <label class="layui-form-label">昵 称</label>
        <div class="layui-input-inline">
            <input name="nickname" placeholder="请输入昵称" autocomplete="off" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item layui-inline">
        <label class="layui-form-label">性 别</label>
        <div class="layui-input-inline">
            <select name="sex" class="layui-select">
                <option value="">- 性别 -</option>
                <!--<?php foreach([1=>'男',2=>'女'] as $key=>$sex): ?>-->
                <!--<?php if(app('request')->get('sex') == $key.''): ?>-->
                <option selected value="<?php echo htmlentities($key); ?>">- <?php echo htmlentities($sex); ?> -</option>
                <!--<?php else: ?>-->
                <option value="<?php echo htmlentities($key); ?>">- <?php echo htmlentities($sex); ?> -</option>
                <!--<?php endif; ?>-->
                <!--<?php endforeach; ?>-->
            </select>
        </div>
    </div>

    <div class="layui-form-item layui-inline">
        <label class="layui-form-label">标 签</label>
        <div class="layui-input-inline">
            <select name="tag" class="layui-select" lay-search="true">
                <option value="">- 粉丝标签 -</option>
                <!--<?php foreach($tags as $key=>$tag): ?>-->
                <!--<?php if(app('request')->get('tag') == $key): ?>-->
                <option selected value="<?php echo htmlentities($key); ?>"><?php echo htmlentities($tag); ?></option>
                <!--<?php else: ?>-->
                <option value="<?php echo htmlentities($key); ?>"><?php echo htmlentities($tag); ?></option>
                <!--<?php endif; ?>-->
                <!--<?php endforeach; ?>-->
            </select>
        </div>
    </div>

    <div class="layui-form-item layui-inline">
        <label class="layui-form-label">国 家</label>
        <div class="layui-input-inline">
            <input name="country" value="<?php echo htmlentities((app('request')->get('country') ?: '')); ?>" placeholder="请输入国家" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item layui-inline">
        <label class="layui-form-label">省 份</label>
        <div class="layui-input-inline">
            <input name="province" value="<?php echo htmlentities((app('request')->get('province') ?: '')); ?>" placeholder="请输入省份" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item layui-inline">
        <label class="layui-form-label">城 市</label>
        <div class="layui-input-inline">
            <input name="city" value="<?php echo htmlentities((app('request')->get('city') ?: '')); ?>" placeholder="请输入城市" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item layui-inline">
        <label class="layui-form-label">时 间</label>
        <div class="layui-input-inline">
            <input name="create_at" id='create_at' value="<?php echo htmlentities((app('request')->get('create_at') ?: '')); ?>" placeholder="关注时间" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item layui-inline">
        <button class="layui-btn layui-btn-primary"><i class="layui-icon">&#xe615;</i> 搜 索</button>
    </div>

</form>
<!-- 表单搜索 结束 -->

<form onsubmit="return false;" data-auto="true" method="post">
    <!--<?php if(empty($list)): ?>-->
    <p class="help-block text-center well">没 有 记 录 哦！</p>
    <!--<?php else: ?>-->
    <input type="hidden" value="resort" name="action">
    <table class="layui-table" lay-skin="line">
        <thead>
        <tr>
            <th class='list-table-check-td'>
                <input data-auto-none="" data-check-target='.list-check-box' type='checkbox'>
            </th>
            <th class='text-left'>用户昵称</th>
            <th class='text-left'>性别</th>
            <th class='text-left'>用户标签</th>
            <th class='text-left'>所在区域</th>
            <th class='text-left'>关注时间</th>
            <th class='text-center'>操作</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach($list as $key=>$vo): ?>
        <tr>
            <td class='list-table-check-td'>
                <input class="list-check-box" value='<?php echo htmlentities($vo['id']); ?>' type='checkbox'>
            </td>
            <td class='text-left nowrap'>
                <img data-tips-image class="headimg" src="<?php echo htmlentities($vo['headimgurl']); ?>">
                <?php echo htmlentities((isset($vo['nickname']) && ($vo['nickname'] !== '')?$vo['nickname']:'<span class="color-desc">未设置微信昵称</span>')); ?>
            </td>
            <td class='text-left'>
                <?php echo $vo['sex']==1 ? '男' : ($vo['sex']==2?'女':'未知'); ?>
            </td>
            <td class="nowrap">
                <?php if(auth("$classuri/tagset")): ?>
                <span><a data-add-tag='<?php echo htmlentities($vo['id']); ?>' data-used-id='<?php echo join(",",array_keys($vo['tags_list'])); ?>' id="tag-fans-<?php echo htmlentities($vo['id']); ?>" class='label label-default add-tag'>+</a></span>
                <?php endif; if(empty($vo['tags_list'])): ?>
                <span class="color-desc">尚未设置标签</span>
                <?php else: foreach($vo['tags_list'] as $k=>$tag): ?><span class="layui-badge layui-bg-gray margin-right-5"><?php echo htmlentities($tag); ?></span><?php endforeach; endif; ?>
            </td>
            <td class='text-left nowrap'>
                <?php echo (isset($vo['country']) && ($vo['country'] !== '')?$vo['country']:'<span class="color-desc">未设置区域信息</span>'); ?><?php echo htmlentities($vo['province']); ?><?php echo htmlentities($vo['city']); ?>
            </td>
            <td class='text-left nowrap'><?php echo htmlentities(format_datetime($vo['subscribe_at'])); ?></td>
            <td class="text-center nowrap">
                <?php if(auth("$classuri/backdel")): ?><a data-update="<?php echo htmlentities($vo['id']); ?>" data-action="<?php echo url('backdel'); ?>">移出黑名单</a><?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php if(isset($page)): ?><p><?php echo $page; ?></p><?php endif; ?>
    <!--<?php endif; ?>-->
</form>
</div>
</div>

<!--表单初始化-->
<script>
    window.laydate.render({range: true, elem: '#create_at'});
    window.form.render();
</script>
<!--引入标签设置-->
<?php if(auth("$classuri/tagset")): ?><style>
    .headimg {
        width: 25px;
        height: 25px;
        border-radius: 50%;
        margin-right: 10px;
    }

    .add-tag {
        font-size: 12px;
        font-weight: 400;
        border-radius: 50%;
        color: #333;
        background: #eee;
        border: 1px solid #ddd;
    }

    .add-tag:hover {
        color: #000 !important;
        border: 1px solid #ccc;
    }

</style>

<div id="tags-box" class="hide">
    <form>
        <div class="row margin-right-0" style='max-height:230px;overflow:auto;'>
            <?php foreach($tags as $key=>$tag): ?>
            <div class="col-xs-4">
                <label class="layui-elip block"><input value="<?php echo htmlentities($key); ?>" type="checkbox"/> <?php echo htmlentities($tag); ?></label>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center margin-top-10">
            <div class="hr-line-dashed margin-top-0"></div>
            <button type="button" data-event="confirm" class="layui-btn layui-btn-sm">保存数据</button>
            <button type="button" data-event="cancel" class="layui-btn layui-btn-sm layui-btn-danger">取消编辑</button>
        </div>
    </form>
</div>

<script>
    // 添加标签
    $('body').find('[data-add-tag]').map(function () {
        var self = this;
        var fans_id = this.getAttribute('data-add-tag');
        var used_ids = (this.getAttribute('data-used-id') || '').split(',');
        var $content = $(document.getElementById('tags-box').innerHTML);
        for (var i in used_ids) {
            $content.find('[value="' + used_ids[i] + '"]').attr('checked', 'checked');
        }
        $content.attr('fans_id', fans_id);
        // 标签面板关闭
        $content.on('click', '[data-event="cancel"]', function () {
            $(self).popover('hide');
        });
        // 标签面板确定
        $content.on('click', '[data-event="confirm"]', function () {
            var tags = [];
            $content.find('input:checked').map(function () {
                tags.push(this.value);
            });
            $.form.load('<?php echo url("@wechat/fans/tagset"); ?>', {fans_id: $content.attr('fans_id'), 'tags': tags.join(',')}, 'post');
        });
        // 限制每个表单最多只能选择三个
        $content.on('click', 'input', function () {
            ($content.find('input:checked').size() > 3) && (this.checked = false);
        });
        // 标签选择面板
        $(this).data('content', $content).on('shown.bs.popover', function () {
            $('[data-add-tag]').not(this).popover('hide');
        }).popover({
            html: true,
            trigger: 'click',
            content: $content,
            title: '标签编辑（最多选择三个标签）',
            template: '<div class="popover" style="max-width:500px" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content" style="width:500px"></div></div>'
        });
    });
</script><?php endif; ?>

<!-- 右则内容区域 结束 -->