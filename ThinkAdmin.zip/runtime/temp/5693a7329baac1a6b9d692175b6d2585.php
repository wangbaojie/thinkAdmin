<?php /*a:2:{s:66:"D:\phpStudy\WWW\ThinkAdmin\application\admin\view\token\index.html";i:1544065269;s:69:"D:\phpStudy\WWW\ThinkAdmin\application\admin\view\public\content.html";i:1525718710;}*/ ?>
<!-- 右则内容区域 开始 -->

<div class="layui-card">
    <!--<?php if(!(empty($title) || (($title instanceof \think\Collection || $title instanceof \think\Paginator ) && $title->isEmpty()))): ?>-->
    <div class="layui-header notselect">
        <div class="pull-left"><span><?php echo htmlentities($title); ?></span></div>
        <div class="pull-right margin-right-15 nowrap">

<!--<?php if(auth("$classuri/add")): ?>-->
<button data-modal='<?php echo url("$classuri/add"); ?>' data-title="添加快递" class='layui-btn layui-btn-sm layui-btn-primary'>添加用户
</button>
<!--<?php endif; ?>-->

<!--<?php if(auth("$classuri/del")): ?>-->
<button data-update data-field='delete' data-action='<?php echo url("$classuri/del"); ?>'
        class='layui-btn layui-btn-sm layui-btn-primary'>删除用户
</button>
<!--<?php endif; ?>-->

</div>
    </div>
    <!--<?php endif; ?>-->
    <div class="layui-card-body">

<!-- 表单搜索 开始 -->
<form class="layui-form layui-form-pane form-search" action="<?php echo request()->url(); ?>" onsubmit="return false" method="get">

    <div class="layui-form-item layui-inline">
        <label class="layui-form-label">用户姓名</label>
        <div class="layui-input-inline">
            <input name="customer_name" value="<?php echo htmlentities((app('request')->get('customer_name') ?: '')); ?>" placeholder="请输入用户姓名"
                   class="layui-input">
        </div>
    </div>

    <div class="layui-form-item layui-inline">
        <label class="layui-form-label">用户手机</label>
        <div class="layui-input-inline">
            <input name="customer_mobile" value="<?php echo htmlentities((app('request')->get('customer_mobile') ?: '')); ?>" placeholder="请输入用户手机"
                   class="layui-input">
        </div>
    </div>

    <div class="layui-form-item layui-inline">
        <label class="layui-form-label">添加时间</label>
        <div class="layui-input-inline">
            <input name="date" id="range-date" value="<?php echo htmlentities((app('request')->get('date') ?: '')); ?>" placeholder="请选择添加时间"
                   class="layui-input">
        </div>
    </div>

    <div class="layui-form-item layui-inline">
        <button class="layui-btn layui-btn-primary"><i class="layui-icon">&#xe615;</i> 搜 索</button>
    </div>

</form>

<script>
    window.laydate.render({range: true, elem: '#range-date'});
    window.form.render();
</script>
<!-- 表单搜索 结束 -->

<form onsubmit="return false;" data-auto="true" method="post">
    <input type="hidden" value="resort" name="action"/>
    <?php if(empty($list)): ?>
    <p class="help-block text-center well">没 有 记 录 哦！</p>
    <?php else: ?>
    <table class="layui-table" lay-skin="line" lay-size="sm">
        <thead>
        <tr>
            <th class='list-table-check-td'>
                <input data-auto-none="none" data-check-target='.list-check-box' type='checkbox'/>
            </th>

            <th class='text-left'>ID</th>
            <th class='text-left'>域名</th>
            <th class='text-left'>key</th>
            <th class='text-left'>机构名称</th>
            <th class='text-left'>ip</th>
            <th class='text-left'>平台</th>
            <th class='text-left'>版本</th>
            <th class='text-left'>结束日期</th>
            <th class='text-left'>创建日期</th>
            <th class='text-left'>操作</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach($list as $key=>$vo): ?>
        <tr>
            <td class='list-table-check-td'>
                <input class="list-check-box" value='<?php echo htmlentities($vo['id']); ?>' type='checkbox'/>
            </td>
            <td class='text-left'><?php echo htmlentities($vo['id']); ?></td>
            <td class='text-left'><?php echo htmlentities($vo['domain']); ?></td>
            <td class='text-left'><?php echo htmlentities($vo['key']); ?></td>
            <td class='text-left'><?php echo htmlentities($vo['name']); ?></td>
            <td class='text-left'><?php echo htmlentities($vo['ip']); ?></td>
            <td class='text-left'>
                <?php if($vo['type']==1): ?>信贷云<?php endif; if($vo['type']==2): ?>中控<?php endif; ?>
            </td>
            <td class='text-left'>
                <?php if($vo['version']>0): ?>
                <?php echo htmlentities($vo['version']); else: ?>
                <span style="color: #00B83F">
                   已授权版
               </span>
                <?php endif; ?>
            </td>
            <td class='text-left'>
                <?php if($vo['status']==-1): ?>
                <span style="color: red">
                禁用中
                </span>
                <?php else: if($vo['end_date']>0): ?>
                <?php echo htmlentities(date('Y年m月d日 H:i:s',!is_numeric($vo['end_date'])? strtotime($vo['end_date']) : $vo['end_date'])); else: ?>
                <span style="color: #00B83F">
                永久使用
                </span>
                <?php endif; endif; ?>
            </td>
            <td class='text-left'><?php echo htmlentities(date('Y年m月d日 H:i:s',!is_numeric($vo['created_at'])? strtotime($vo['created_at']) : $vo['created_at'])); ?></td>
            <td class='text-left nowrap'>
                <span class="text-explode">|</span>
                <!--<?php if(auth("$classuri/edit")): ?>-->
                <?php if($vo['end_date']>0): ?>
                <a data-title="编辑试用" data-modal='<?php echo url("$classuri/edit"); ?>?id=<?php echo htmlentities($vo['id']); ?>'>编辑试用</a>
                <?php else: ?>
                <a style="color: #cccccc" disabled="true">编辑试用</a>
                <?php endif; ?>
                <!--<?php endif; ?>-->
                <!--<?php if(auth("$classuri/forever")): ?>-->
                <span class="text-explode">|</span>
                <?php if($vo['end_date']>0): ?>
                <a data-title="永久授权" data-modal='<?php echo url("$classuri/forever"); ?>?id=<?php echo htmlentities($vo['id']); ?>'>永久授权</a>
                <?php else: ?>
                <a style="color: #cccccc" disabled="true">永久授权</a>
                <?php endif; ?>
                <!--<?php endif; ?>-->
                <!--<?php if(auth("$classuri/change")): ?>-->
                <span class="text-explode">|</span>
                <a data-title="查看变更记录" data-modal='<?php echo url("$classuri/change"); ?>?pid=<?php echo htmlentities($vo['id']); ?>'>查看变更记录</a>
                <!--<?php endif; ?>-->
                <!--<?php if(auth("$classuri/change")): ?>-->
                <span class="text-explode">|</span>
                <?php if($vo['status']==99): ?>
                <a data-title="查看变更记录" data-modal='<?php echo url("$classuri/prohibit"); ?>?id=<?php echo htmlentities($vo['id']); ?>'>禁用</a>
                <?php elseif($vo['status']==-1): ?>
                <a data-title="查看变更记录" data-modal='<?php echo url("$classuri/prohibit"); ?>?id=<?php echo htmlentities($vo['id']); ?>'>启用</a>
                <?php endif; ?>
                <!--<?php endif; ?>-->
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php if(isset($page)): ?><p><?php echo $page; ?></p><?php endif; endif; ?>
</form>
</div>
</div>

<!-- 右则内容区域 结束 -->